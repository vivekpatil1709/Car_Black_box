/*  
 *  Name : Vivek Bharat Patil
 *  Date : 08/11/2024
 *  Project Name : Implementation of Car Black Box
 */


#include <xc.h>
#include "dashboard.h"

void init_config()
{
    // MATRIX Initalise
    
    /* Config PORTB as digital */
	ADCON1 = 0x0F;

	/* Set Rows (RB7 - RB5) as Outputs and Columns (RB4 - RB1) as Inputs */
	TRISB = 0x1E;

	/* Set PORTB input as pull up for columns */
	RBPU = 0;

	MATRIX_KEYPAD_PORT = MATRIX_KEYPAD_PORT | 0xE0;
    
    //CLCD INITALIZSE 
    
    /* Set PortD as output port for CLCD data */
	TRISD = 0x00;
	/* Set PortC as output port for CLCD control */
	TRISC = TRISC & 0xF8;

	CLCD_RW = LO;

	CURSOR_HOME;
	TWO_LINE_5x8_MATRIX_8_BIT;
	DISP_ON_AND_CURSOR_OFF;
	CLEAR_DISP_SCREEN;
    
    //ADC INITALIZE
    
    /* Selecting right justified ADRES Registers order */
	ADFM = 1;

	/* 
	 * Acqusition time selection bits 
	 * Set for 4 Tad
	 */
	ACQT2 = 0;
	ACQT1 = 1;
	ACQT0 = 0;

	/*
	 * Selecting the conversion clock of Fosc / 32 -> 1.6usecs -> 1Tad
	 * Our device frequency is 20 MHz
	 */
	ADCS0 = 0;
	ADCS1 = 1;
	ADCS2 = 0;

	/* Stop the conversion to start with */
	GODONE = 0;

	

	/* Voltage reference bit as VSS */
	VCFG1 = 0;
	/* Voltage reference bit as VDD */
	VCFG0 = 0;

	/* Just clearing the ADRESH & ADRESL registers, for time pass */
	ADRESH = 0;
	ADRESL = 0;

	/* Turn ON the ADC module */
	ADON = 1;
   
    // UART Initilisation
    /* Serial initialization */
	RX_PIN = 1;
	TX_PIN = 0;

	/* TXSTA:- Transmitor Status and control Register */
	/* 9bit TX enable or disable bit */ 
	TX9 = 0;
	/* UART Tarsmition enable bit */
	TXEN = 1;
	/* Synchronous or Asynchronous mode selection */
	/* Asynchronous */
	SYNC = 0;
	/* Send the Break character bit */
	SENDB = 0;
	/* Low or High baud rate selection bit */
	/* High Baud Rate */
	BRGH = 1;

	/* RCSTA :- Recepition Status and control Register */
	/* TX/RC7 and RX/RC6 act as serial port */ 
	SPEN = 1;
	/* 9bit RX enable or disable bit */
	RX9 = 0;
	/* Continous reception enable or disable */ 
	CREN = 1;

	/* BAUDCTL:- Baud rate control register */

	/* 16bit baud generate bit */ 
	BRG16 = 0;
	

	/* Baud Rate Setting Register */
	/* Set to 10 for 115200, 64 for 19200 and 129 for 9600 */
	SPBRG = 129;


	/* TX interrupt flag bit */
	TXIF = 0;

	/* RX interrupt enable bit */
	RCIF = 0;
    
    init_i2c();
	init_ds1307();
}

//CLCD FUNCTIONS

void clcd_write(unsigned char byte, unsigned char control_bit)
{
	CLCD_RS = control_bit;
	CLCD_PORT = byte;

	/* Should be atleast 200ns */
	CLCD_EN = HI;
	CLCD_EN = LO;

	PORT_DIR = INPUT;
	CLCD_RW = HI;
	CLCD_RS = INSTRUCTION_COMMAND;

	do
	{
		CLCD_EN = HI;
		CLCD_EN = LO;
	} while (CLCD_BUSY);

	CLCD_RW = LO;
	PORT_DIR = OUTPUT;
}

void clcd_print(const unsigned char data[], unsigned char addr)
{
	clcd_write(addr, INSTRUCTION_COMMAND);
	while (*data != '\0')
	{
		clcd_write(*data++, DATA_COMMAND);
	}
}

void clcd_putch(const unsigned char data, unsigned char addr)
{
	clcd_write(addr, INSTRUCTION_COMMAND);
	clcd_write(data, DATA_COMMAND);
}

//MATRIX FUNCTIONS

unsigned char scan_key(void)
{
	ROW1 = LO;
	ROW2 = HI;
	ROW3 = HI;

	if (COL1 == LO)
	{
		return 1;
	}
	else if (COL2 == LO)
	{
		return 4;
	}
	else if (COL3 == LO)
	{
		return 7;
	}
	else if (COL4 == LO)
	{
		return 10;
	}

	ROW1 = HI;
	ROW2 = LO;
	ROW3 = HI;

	if (COL1 == LO)
	{
		return 2;
	}
	else if (COL2 == LO)
	{
		return 5;
	}
	else if (COL3 == LO)
	{
		return 8;
	}
	else if (COL4 == LO)
	{
		return 11;
	}

	ROW1 = HI;
	ROW2 = HI;
	ROW3 = LO;
	/* TODO: Why more than 2 times? */
	ROW3 = LO;

	if (COL1 == LO)
	{
		return 3;
	}
	else if (COL2 == LO)
	{
		return 6;
	}
	else if (COL3 == LO)
	{
		return 9;
	}
	else if (COL4 == LO)
	{
		return 12;
	}

	return 0xFF;
}

unsigned char read_switches(unsigned char detection_type)
{
	static unsigned char once = 1, key;

	if (detection_type == STATE_CHANGE)
	{
		key = scan_key();
		if(key != 0xFF && once  )
		{
			once = 0;
			return key;
		}
		else if(key == 0xFF)
		{
			once = 1;
		}
	}
	else if (detection_type == LEVEL_CHANGE)
	{
		return scan_key();
	}

	return 0xFF;
}

//ADC FUNCTIONS 

unsigned int read_adc(unsigned char channel)
{
	unsigned int reg_val;

	/*select the channel*/
	ADCON0 = (ADCON0 & 0xC3) | (channel << 2);

	/* Start the conversion */
	GO = 1;
	while (GO);
	reg_val = (ADRESH << 8) | ADRESL; 

	return reg_val;
}
// I2C Intiliasize
void init_i2c(void)
{
	/* Set SCL and SDA pins as inputs */
	TRISC3 = 1;
	TRISC4 = 1;
	/* Set I2C master mode */
	SSPCON1 = 0x28;

	SSPADD = 0x31;
	/* Use I2C levels, worked also with '0' */
	CKE = 0;
	/* Disable slew rate control  worked also with '0' */
	SMP = 1;
	/* Clear SSPIF interrupt flag */
	SSPIF = 0;
	/* Clear bus collision flag */
	BCLIF = 0;
}

void i2c_idle(void)
{
	while (!SSPIF);
	SSPIF = 0;
}

void i2c_ack(void)
{
	if (ACKSTAT)
	{
		/* Do debug print here if required */
	}
}

void i2c_start(void)
{
	SEN = 1;
	i2c_idle();
}

void i2c_stop(void)
{
	PEN = 1;
	i2c_idle();
}

void i2c_rep_start(void)
{
	RSEN = 1;
	i2c_idle();
}

void i2c_write(unsigned char data)
{
	SSPBUF = data;
	i2c_idle();
}

void i2c_rx_mode(void)
{
	RCEN = 1;
	i2c_idle();
}

void i2c_no_ack(void)
{
	ACKDT = 1;
	ACKEN = 1;
}

unsigned char i2c_read(void)
{
	i2c_rx_mode();
	i2c_no_ack();

	return SSPBUF;
}

//  RTC Initiasilation

void init_ds1307(void)
{
	unsigned char dummy;

	/* Setting the CH bit of the RTC to Stop the Clock */
	dummy = read_ds1307(SEC_ADDR);
	write_ds1307(SEC_ADDR, dummy | 0x80); 

	/* Seting 12 Hr Format */
	dummy = read_ds1307(HOUR_ADDR);
	write_ds1307(HOUR_ADDR, dummy | 0x40); 

	/* 
	 * Control Register of DS1307
	 * Bit 7 - OUT
	 * Bit 6 - 0
	 * Bit 5 - OSF
	 * Bit 4 - SQWE
	 * Bit 3 - 0
	 * Bit 2 - 0
	 * Bit 1 - RS1
	 * Bit 0 - RS0
	 * 
	 * Seting RS0 and RS1 as 11 to achive SQW out at 32.768 KHz
	 */ 
	write_ds1307(CNTL_ADDR, 0x93); 

	/* Clearing the CH bit of the RTC to Start the Clock */
	dummy = read_ds1307(SEC_ADDR);
	write_ds1307(SEC_ADDR, dummy & 0x7F); 

}

void write_ds1307(unsigned char address, unsigned char data)
{
	i2c_start();
	i2c_write(SLAVE_WRITE);
	i2c_write(address);
	i2c_write(data);
	i2c_stop();
}

unsigned char read_ds1307(unsigned char address)
{
	unsigned char data;

	i2c_start();
	i2c_write(SLAVE_WRITE);
	i2c_write(address);
	i2c_rep_start();
	i2c_write(SLAVE_READ);
	data = i2c_read();
	i2c_stop();

	return data;
}

// RTC FUNCTIONS
static void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}

// EXTERNAL EEPROM FUNCTIONS
void write_external_eeprom(unsigned char address, unsigned char data)
{
    i2c_start();
    i2c_write(SLAVE_WRITE_E);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
    for (unsigned int wait = 3000;wait--;);
}

unsigned char read_external_eeprom(unsigned char address)
{
    unsigned char data;

    i2c_start();
    i2c_write(SLAVE_WRITE_E);
    i2c_write(address);
    i2c_rep_start();
    i2c_write(SLAVE_READ_E);
    data = i2c_read();
    i2c_stop();

    return data;
}

// UART FUNCTIONS
void putch(unsigned char byte) 
{
	/* Output one byte */
	/* Set when register is empty */
	while(!TXIF)
	{
		continue;
	}
	TXIF = 0;
	TXREG = byte;
} 

int puts(const char *s)
{
	while(*s)		
	{
		putch(*s++);	
	}
	return 0;
}

unsigned char getch(void)
{
	/* Retrieve one byte */
	/* Set when register is not empty */
	while(!RCIF)
	{
		continue;
	}
	RCIF = 0;
	return RCREG;
}

unsigned char getche(void)
{
	unsigned char c;

	putch(c = getch());

	return (c);
}


void view_log()
{
    CLEAR_DISP_SCREEN;
    long int delay=0,i=0;                                // Initialisiation the variables
    
    while(1)
    {
        key = read_switches(STATE_CHANGE);
        if(view_flag)                                  // Checking the flag value to show events are recored or not
        {
            clcd_print("# VIEW LOG :", LINE1(0));
            if(key == MK_SW1 && i>0 && (dummy[i][0] != '#'))
            {
                i--;
            }
            else if(key == MK_SW2 && i<9 && (dummy[i+1][0] != '#'))
            {
                i++;
            }
            clcd_print(dummy[i], LINE2(0));
        }
        else
        {
            clcd_print("# NO LOG...", LINE1(0));
            clcd_print("TO DISPLAY :(", LINE2(0));
            if(delay++==2000)
            {
                CLEAR_DISP_SCREEN;
                break;
            }
        }
        
        if(key==MK_SW12)                // Initialisiation the variables
        {
            CLEAR_DISP_SCREEN;
            key=0;
            break;
        }
    }   
}

int set_time()
{
    CLEAR_DISP_SCREEN;
    
    char flag=0;                         // Initialisiation the variables 
    int blink=0;
    clcd_print("HH:MM:SS", LINE1(0));
    key=0;
    while(1)
    {
        key = read_switches(STATE_CHANGE);
        
        if(key == MK_SW2 && flag<3)         // Changing the Field using the flag value
        {
            flag++;
            blink=0;
        }
        else if(flag==3)
        {
            blink=0;
            flag=0;
        }
        
        if(flag == 0)
        {
            if(blink<700)                                 // Blink the Field
            {
                clcd_putch(hrs/10 + '0', LINE2(0));
                clcd_putch(hrs%10 + '0', LINE2(1));
                blink++;
            }
            else if(blink<1400)
            {
                clcd_putch(' ', LINE2(0));
                clcd_putch(' ', LINE2(1));
                blink++;
            }
            else
                blink=0;
            
                clcd_putch(min/10 + '0', LINE2(3));
                clcd_putch(min%10 + '0', LINE2(4));
                clcd_putch(sec/10 + '0', LINE2(6));
                clcd_putch(sec%10 + '0', LINE2(7));
        }
        else if(flag == 1)
        {
            if(blink<700)
            {
                clcd_putch(min/10 + '0', LINE2(3));
                clcd_putch(min%10 + '0', LINE2(4));
                blink++;
            }
            else if(blink<1400)
            {
                blink++;
                clcd_putch(' ', LINE2(3));
                clcd_putch(' ', LINE2(4));
            }
            else
                blink=0;
            
            
                clcd_putch(hrs/10 + '0', LINE2(0));
                clcd_putch(hrs%10 + '0', LINE2(1));
                clcd_putch(sec/10 + '0', LINE2(6));
                clcd_putch(sec%10 + '0', LINE2(7));
        }
        else if(flag == 2)
        {
            if(blink<700)
            {
                blink++;
                clcd_putch(sec/10 + '0', LINE2(6));
                clcd_putch(sec%10 + '0', LINE2(7));
            }
            else if(blink<1400)
            {
                blink++;
                clcd_putch(' ', LINE2(6));
                clcd_putch(' ', LINE2(7));
            }
            else
                blink=0;
            
                clcd_putch(hrs/10 + '0', LINE2(0));
                clcd_putch(hrs%10 + '0', LINE2(1));
                
                clcd_putch(min/10 + '0', LINE2(3));
                clcd_putch(min%10 + '0', LINE2(4));
        }
        clcd_putch(':', LINE2(2));
        clcd_putch(':', LINE2(5));
        if(key == MK_SW1)                        // Setting the time using flag value
        {
            if(flag==0 && hrs++==23)
                hrs=0;
            else if(flag==1 && min++==59)
                min=0;
            else if(flag==2 && sec++==59)
                sec=0;
        }
        
        if(key == MK_SW11)               // For Returning back to the Main function
        {
            key=0;
            hrs=((hrs/10<<4)| hrs%10);
            min=((min/10<<4)| min%10);           // Storing the BCD values into the RTC HOUR,MIN,SEC Addresses
            sec=((sec/10<<4)| sec%10);
            write_ds1307(HOUR_ADDR,hrs);
            write_ds1307(MIN_ADDR,min);
            write_ds1307(SEC_ADDR,sec);
            return 0;
        }
        
        if(key == MK_SW12)                              // Initialisiation the variables
        {
            key=0;
            CLEAR_DISP_SCREEN;
            return 1;
        }
    }
}
void download_log()
{
    CLEAR_DISP_SCREEN;
    clcd_print("DOWNLOADING.... ", LINE1(0));
    clcd_print("THROUGH UART", LINE2(0));
    for(long int i=500000;i--;);                   
    CLEAR_DISP_SCREEN;
    
    int i=0;
    if(dummy[0][0]=='#' || view_flag==0)       // Displaying the Data on Tera Term & checking the condition if the events are recorded or not
    {
        puts("Events are not recorded....!\n\r");
        puts("\n\r");
    }
    else
    {
        puts("NO.  TIME  EV SP\n\r");
        while(dummy[i][0]!='#' && i<flag_e)
        {
            puts(dummy[i++]);
            puts("\n\r");
        }
        puts("Downloading Events Successfully..!\n\r");
        puts("\n\r");
    }
    
}
void clear_log()
{
    CLEAR_DISP_SCREEN;
    view_flag=0;
    clcd_print("CLEARING LOGS", LINE1(0));
    clcd_print("Just a Minute :)", LINE2(0));
    for(long int i=500000;i--;);
    while(address<100)
    {
        write_external_eeprom(address++,0x00);          // Clearing the External EEPROM Memeory
    }
    for(int i=0;i<10;i++)
    {
        events[i][0]='#';
        dummy[i][0]='#';
    }
    address=0;
    flag_e=0;
    CLEAR_DISP_SCREEN;
}

int dash()
{
    static int star,i,flag;                          // declearing the variables
    if(i==0)
    {
        CLEAR_DISP_SCREEN;
        key=0;                                     // Making the Key value as '0'.
        flag=1;
        i++;
    }
    if(key==MK_SW1 )                                //Scrolling the Dash Board Menu depending on the star value
    {
        CLEAR_DISP_SCREEN;
        if(flag==0 || star==0)
            flag=1;
        else 
           star--;
        if(count>1)
           count--;
    }
    else if(key==MK_SW2 )
    {
        CLEAR_DISP_SCREEN;
        if(flag || star==2)
            flag=0;
        else 
           star++;
        
        if(count<4)
            count++;
    }
    
    
    if(key==MK_SW11)                          // Selecting the DASHBOARD MENUS depending on the count value
    {
        if(count==1)
            view_log();                        // calling the view_log function
        else if(count==2)
        {
            hrs=(((time[0]-48)*10) + (time[1]-48));      // Storing the RTC time value into the variables
            min=(((time[3]-48)*10) + (time[4]-48));
            sec=(((time[6]-48)*10) + (time[7]-48));
            
            if(set_time()==0)                  // calling the set_time function
            {
                i=0;
                count=1;
                star=0;
                flag=1;
                return 0;
            }
            else
            {
                count=1;
                star=0;
                flag=1;
            }
        }
        else if(count==3)
        {
            download_log();                        // calling the download_log function
            flag=1;
            star=0;
            count=1;
        }
        else if(count==4)
        {
            clear_log();         // calling the clear_log function
            flag=1;
            star=0;
            count=1;
        }
        
    }
    else
    {
        if(flag)
            clcd_putch('*',LINE1(0));                  // Displaying the '*' depending on the flag value
        else
            clcd_putch('*',LINE2(0));
    
        clcd_print(dash_board[star], LINE1(1));           // Displaying the DASHBOARD MENUS
        clcd_print(dash_board[star+1], LINE2(1));
    }
    
    
    if(key==MK_SW12)                        // For Returning back from this Function
    { 
        CLEAR_DISP_SCREEN;
        i=0;
        star=0;
        count=1;
        return 0;
    }
    else
        return 1;
}
void main(void) {
    init_config();                                  // initialisation of peripherals
    
    int i=0,speed,mode=0,flag1=0;                   // initialisation of the variables
    while(1)
    {
        get_time();                                 // accessing the time array for the RTC
        key = read_switches(STATE_CHANGE);          // Read the key value using this function
        speed=(read_adc(CHANNEL4)/10);              // Read the Potientiometer value using ADC funcction
        if(key==MK_SW11 || mode)                    // Switching to the DASHBOARD MENU
        {  
            mode=dash();                            // calling the DASHBOARD MENU
        }
        else
        {
            if(speed<100)                                // Increamenting the value upto 99 and displaying
            {
                clcd_putch((speed/10)+48,LINE2(14));
                clcd_putch((speed%10)+48,LINE2(15));
            }
            
            if(key==MK_SW1 && i<7)                       // Increamenting the Gear value upto G5 
            {
                i++;
                view_flag=1;
                flag1=1;
                if(flag_e==10)                           // checking the flag_e  for events
                {
                    for(int i=0;i<9;i++)
                    {
                        int j=0;
                        backup=address;                  // storing the address into the backup
                        while(events[i][j]!='\0')
                        {
                            events[i][j]=events[i+1][j];
                            write_external_eeprom(address++,events[i][j]);// storing the data of events into the External EEPROM
                            j++;
                        }
                        for(int k=0; k<=16; k++)
                        {
                            if(k==0)
                            {
                                dummy[i][k]='0'+(i);
                            }
                            else if(k==4 || k==7)
                            {
                                dummy[i][k]=':';
                            }
                            else if(k==1 || k==10 || k==13)
                            {
                                dummy[i][k]=' ';
                            }
                            else if(k==16)
                                dummy[i][k]='\0';
                            else
                                dummy[i][k]=read_external_eeprom(backup++);// Reading the data of events from the External EEPROM into the dummy array
                        }
                    }
                    flag_e=9;
                } 
                events[flag_e][0]=time[0];
                events[flag_e][1]=time[1];
                events[flag_e][2]=time[3];
                events[flag_e][3]=time[4];
                events[flag_e][4]=time[6];
                events[flag_e][5]=time[7];
                events[flag_e][6]=Gear[i][0];
                events[flag_e][7]=Gear[i][1];
                events[flag_e][8]='0'+speed/10;
                events[flag_e][9]='0'+speed%10;
                events[flag_e][10]='\0';
                flag_e++;   
            }
            else if(key==MK_SW2 && i>1 && i!=8)              // Decreamenting the Gear value upto GN
            {
                i--;
                flag1=1;
                view_flag=1;
                if(flag_e==10)
                {
                    for(int i=0;i<9;i++)
                    {
                        int j=0;
                        backup=address;
                        while(events[i][j]!='\0')
                        {
                            events[i][j]=events[i+1][j];
                            write_external_eeprom(address++,events[i][j]);
                            j++;
                        }
                        for(int k=0; k<=16; k++)
                        {
                            if(k==0)
                            {
                                dummy[i][k]='0'+(i);
                            }
                            else if(k==4 || k==7)
                            {
                                dummy[i][k]=':';
                            }
                            else if(k==1 || k==10 || k==13)
                            {
                                dummy[i][k]=' ';
                            }
                            else if(k==16)
                                dummy[i][k]='\0';
                            else
                                dummy[i][k]=read_external_eeprom(backup++);// Reading the data of events from the External EEPROM into the dummy array
                        }
                    }
                    flag_e=9;
                }
                events[flag_e][0]=time[0];
                events[flag_e][1]=time[1];
                events[flag_e][2]=time[3];
                events[flag_e][3]=time[4];
                events[flag_e][4]=time[6];
                events[flag_e][5]=time[7];
                events[flag_e][6]=Gear[i][0];
                events[flag_e][7]=Gear[i][1];
                events[flag_e][8]='0'+speed/10;
                events[flag_e][9]='0'+speed%10;
                events[flag_e][10]='\0';
                flag_e++;
            }
            else if(key==MK_SW3)
            {
                i=8;
                flag1=1;
                view_flag=1;
                if(flag_e==10)
                {
                    for(int i=0;i<9;i++)
                    {
                        int j=0;
                        backup=address;
                        while(events[i][j]!='\0')
                        {
                            events[i][j]=events[i+1][j];
                            write_external_eeprom(address++,events[i][j]);
                            j++;
                        }
                        for(int k=0; k<=16; k++)
                        {
                            if(k==0)
                            {
                                dummy[i][k]='0'+(i);
                            }
                            else if(k==4 || k==7)
                            {
                                dummy[i][k]=':';
                            }
                            else if(k==1 || k==10 || k==13)
                            {
                                dummy[i][k]=' ';
                            }
                            else if(k==16)
                                dummy[i][k]='\0';
                            else
                                dummy[i][k]=read_external_eeprom(backup++);// Reading the data of events from the External EEPROM into the dummy array
                        }
                    }
                    flag_e=9;
                }
                events[flag_e][0]=time[0];
                events[flag_e][1]=time[1];
                events[flag_e][2]=time[3];
                events[flag_e][3]=time[4];
                events[flag_e][4]=time[6];
                events[flag_e][5]=time[7];
                events[flag_e][6]=Gear[i][0];
                events[flag_e][7]=Gear[i][1];
                events[flag_e][8]='0'+speed/10;
                events[flag_e][9]='0'+speed%10;
                events[flag_e][10]='\0';
                flag_e++;
            }
            else if(((key==MK_SW1) || (key==MK_SW2)) && i==8) // If the Collision happen By Switching any key ( 1or 2) Gear is shifted to Neutral(GN)
            {
                i=1;
            }
            
            if(flag1)
            {
                backup=address;
            
                for(int i=0; i<10; i++)
                {
                   write_external_eeprom(address++,events[flag_e-1][i]); //storing the data of 1 event into the External EEPROM 
                }
                
                for(int i=0; i<=16; i++)
                {
                    if(i==0)
                    {
                        dummy[flag_e-1][i]='0'+(flag_e-1);
                    }
                    else if(i==4 || i==7)
                    {
                        dummy[flag_e-1][i]=':';
                    }
                    else if(i==1 || i==10 || i==13)
                    {
                        dummy[flag_e-1][i]=' ';
                    }
                    else if(i==16)
                        dummy[flag_e-1][i]='\0';
                    else
                        dummy[flag_e-1][i]=read_external_eeprom(backup++);//Reading the data of 1 event from the External EEPROM
                }
                flag1=0;
                
                if(address == 100)               // After reaching the 100 address, address value is changed to 0;  
                {
                    address=0;
                }
            }
            
            clcd_print("  TIME    EV  SP", LINE1(0));
            clcd_print(Gear[i], LINE2(10));                     // Displaying the Gear , Time ,Speed 
            clcd_print(time,LINE2(0));
        }
    }
    return;
}
